export interface Patient {
  patient_id: number
  id: number
  name: string
  email: string
  personal_id: string
  age: number
  gender: string
  address: string
  contact_no: string
  pendingPrescriptions: number
}
