export interface Medicine {
  medicine_id: number
  name: string
  description: string
  stock_quantity: number
  price: number
}
